This program takes a list of pieces for hunting stages in Sonic Adventure 2 and produces data from it. It supports two different formats:
1. A setfile json taken from the game's files and converted using OnVar's set editor tool.
	The program automatically detects the level, but requires a CSV of the hints and their associated piece IDs. This can be easily obtained from
	https://docs.google.com/spreadsheets/d/129TvB5V6GOjQ8z-pwK97eSCrRwpAe70D2UBB2xLJQx8/
2. A CSV file made by the user. Each line should have its own piece. A readable piece is in the following format:
	Name,ID,X,Y,Z
	Any line that doesn't follow this format is ignored.

For hints, put quotes around the name if you want to include a comma in it. Excel does this automatically when exporting to a CSV and the program is capable of reading it that way.
Remember to distinguish between pieces with the same first hint!

Meteor Herd's pieces have been included as a sample for both formats.

The program can perform the following functions:
Mode -1: Lists the pieces. Useful for debugging setfiles, as there are sometimes pieces put in the _u files.
Mode 0: Generates a list of possible combos. Default mode.
Mode 1: Generates a list of Piece 1 to Piece 2 combos.
Mode 2: Generates a list of Piece 1 to Piece 3 combos.
Mode 3: Shows the distances from each Piece 1 to each Piece 2.
Mode 4: Shows the cross products from each Piece 1 and 2 set to each Piece 3.